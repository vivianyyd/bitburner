/** 
 * @param {NS} ns 
 * Breaks into child servers and initates setup process in them.
 * Initiates the weaken-grow-hack loop in the current server.
**/
export async function main(ns) {
	var name = ns.args[0];
	var parent = ns.args[1];
	var children = ns.scan(name);
	for (let child of children) {
		if (child == parent) { continue; }
		// automate backdoor if it ever takes less than 32G
		ns.connect(child);
		ns.installBackdoor();
	}
}