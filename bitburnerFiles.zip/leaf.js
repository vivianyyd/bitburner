/** 
 * @param {NS} ns 
 * Select a server to target depending on the host, and spawn as many threads as possible targeting it. 
**/
export async function main(ns) {
	var name = ns.getHostname();
	if (ns.getServerMaxMoney(name) != 0) {
		var target = name;
	}
	else {
		var others = [];
		for (var i=0; i < 4; i++) others.push('catalyst');
		for (var i=0; i < 3; i++) others.push('aevum-police');
		for (var i=0; i < 3; i++) others.push('netlink');
		others.push('comptek', 'the-hub', 'johnson-ortho', 'crush-fitness', 'omega-net', 'silver-helix',
		'phantasy', 'iron-gym', 'max-hardware', 'zer0', 'neo-net', 'harakiri-sushi');
		
		var num = 0;
		var dash = name.lastIndexOf('-');
		if (dash != -1) {
			var numstr = Number(name.substring(dash + 1));
			if (!Number.isNaN(numstr)) num = numstr;
		}
		var ind = num % others.length;
		var target = others[ind];
	}

	var ram = ns.getServerMaxRam(name) - ns.getServerUsedRam(name) + ns.getScriptRam('leaf.js');
	var hgw = ns.getScriptRam('hackgw.js');
	var threads = Math.floor(ram / hgw);
	ns.spawn('hackgw.js', threads, target);
}

// For now, targets are manually chosen based on ports open, hack level, and max money.

// 3 ports open
// others = ['comptek', 'the-hub', 'johnson-ortho', 'omega-net', 'silver-helix', 'crush-fitness', 'phantasy', 'iron-gym'];

// 5 ports open, more distributed
// others = ['catalyst', 'catalyst', 'aevum-police', 'aevum-police', 'netlink', 'netlink',
// 	'comptek', 'comptek', 'the-hub', 'the-hub', 'johnson-ortho', 'omega-net', 'silver-helix',
// 	'crush-fitness', 'phantasy', 'iron-gym', 'max-hardware', 'zer0', 'neo-net', 'harakiri-sushi',
// 	'hong-fang-tea', 'nectar-net', 'joesguns', 'sigma-cosmetics', 'foodnstuff'];