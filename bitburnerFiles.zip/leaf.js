/** 
 * @param {NS} ns 
 * Select a server to target depending on the host, and spawn as many threads as possible targeting it. 
**/
export async function main(ns) {
	var name = ns.getHostname();
	if (ns.getServerMaxMoney(name) != 0) {
		var target = name;
	}
	// else if (name.includes('home-')){   // comment for when home servers are not huge
	else {  // uncomment for when home servers are not huge
		var others = [];
		others.push('alpha-ent');
		others.push('rho-construction');
		others.push('summit-uni');
		others.push('aevum-police');
		others.push('catalyst');
		others.push('rothman-uni');
		others.push('netlink');
		others.push('comptek', 'the-hub', 'johnson-ortho', 'crush-fitness', 'omega-net', 'silver-helix',
		'phantasy', 'iron-gym', 'max-hardware', 'zer0', 'neo-net', 'harakiri-sushi', 'hong-fang-tea', 'nectar-net',
		'joesguns', 'sigma-cosmetics', 'foodnstuff', 'n00dles');
		
		var num = 0;
		var dash = name.lastIndexOf('-');
		if (dash != -1) {
			var numstr = Number(name.substring(dash + 1));
			if (!Number.isNaN(numstr)) num = numstr;
		}
		var ind = num % others.length;
		var target = others[ind];
	}   // uncomment for when home servers are not huge

	var ram = ns.getServerMaxRam(name);  //  - ns.getServerUsedRam(name) + ns.getScriptRam('leaf.js')
	var hgw = ns.getScriptRam('hackgw.js');
	var threads = Math.floor(ram / hgw);
	ns.spawn('hackgw.js', threads, target);
	// }  // comment for when home servers are not huge
}

// For now, targets are manually chosen based on ports open, hack level, and max money.

// 3 ports open
// others = ['comptek', 'the-hub', 'johnson-ortho', 'omega-net', 'silver-helix', 'crush-fitness', 'phantasy', 'iron-gym'];

// 5 ports open, more distributed
// others = ['catalyst', 'catalyst', 'aevum-police', 'aevum-police', 'netlink', 'netlink',
// 	'comptek', 'comptek', 'the-hub', 'the-hub', 'johnson-ortho', 'omega-net', 'silver-helix',
// 	'crush-fitness', 'phantasy', 'iron-gym', 'max-hardware', 'zer0', 'neo-net', 'harakiri-sushi',
// 	'hong-fang-tea', 'nectar-net', 'joesguns', 'sigma-cosmetics', 'foodnstuff'];

// 5 ports open, higher level
// others.push('alpha-ent');
// others.push('alpha-ent');
// others.push('rho-construction');
// others.push('rho-construction');
// others.push('summit-uni');
// others.push('summit-uni');
// others.push('aevum-police');
// others.push('aevum-police');
// others.push('catalyst');
// others.push('catalyst');
// others.push('rothman-uni');
// others.push('netlink');
// others.push('netlink');
// others.push('comptek', 'the-hub', 'johnson-ortho', 'crush-fitness', 'omega-net', 'silver-helix',
// 'phantasy', 'iron-gym', 'max-hardware', 'zer0', 'neo-net', 'harakiri-sushi');