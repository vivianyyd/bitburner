/** @param {NS} ns **/
export async function main(ns) {
	var numservers = ns.args[0];
	for (var i = 0; i < numservers; i++) {
		var serv = 'home-' + i;
		var threads = Math.floor(ns.getServerMaxRam(serv) / 1.75);
		ns.exec('weak.js', serv, threads);
	}
}