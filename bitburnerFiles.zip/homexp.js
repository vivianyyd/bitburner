/** 
 * @param {NS} ns 
 * Cheeses hacking xp on $1 purchased home servers.
**/
export async function main(ns) {
	if (ns.args.length < 1){
		ns.tprint('Use `run homexp.js [n]` to cheese hacking XP on [n] purchased home servers.')
	}
	var numservers = ns.args[0];
	for (var i = 0; i < numservers; i++) {
		var serv = 'home-' + i;
		ns.killall(serv);
		var threads = Math.floor(ns.getServerMaxRam(serv) / 1.75);
		ns.exec('weak.js', serv, threads);
	}
}