/** @param {NS} ns **/
export async function main(ns) {
	ns.tprint(ns.getServerMaxRam('asdf'));

	// var ram = Math.pow(2, 20);  // 13, 18, 20
	// var i = 6;
	// // leave these lines uncommented if there already exist all 25 servers
	// ns.killall('home-' + i);
	// ns.deleteServer('home-' + i);
	// var baby = ns.purchaseServer('home-' + i, ram);
}