/** 
 * @param {NS} ns 
 * Runs as many instances of adv as possible, with threading, on the machine [name], which must be the current machine.
 * If [name] has no money, the machine is to instead target 'phantasy'.
 * **/
export async function main(ns) {
	var name = ns.args[0];

	if (name != 'home') {  // don't loop on home (this script is used by setup, but home needs to run buyservs after setup and before looping.)
		if (ns.getServerMaxMoney(name) != 0) {
			var target = name;
		}
		else {
			// servers on 'others' have a high max money (1.25b, 600m, 500m).
			var others = ['comptek', 'the-hub', 'johnson-ortho', 'omega-net', 'silver-helix', 'crush-fitness', 'phantasy', 'iron-gym'];  // length must be less than 10. If greater, modify code to isolate entire substring after the last '-'
			var digit = Number(name.charAt(name.length - 1));
			var ind = Number.isNaN(digit) ? 0 : digit % others.length;  // If it is an owned server (ends in a digit), we find a target based on that digit.
			ns.tprint('Max money of ', name, ' was 0. Instead targeting ', others[ind]);
			var target = others[ind];
		}
		ns.spawn('hack.js', 1, name, target);
	}
}