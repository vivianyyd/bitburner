/** 
 * @param {NS} ns 
 * Usage: `run stats.js home home`
 * This script recursively kills all processes on all servers. The `start` command must be used after running.
**/
export async function main(ns) {
	var name = ns.args[0];
	var parent = ns.args[1];
	var children = ns.scan(name);

	ns.tprint('Server,Min level,Min ports,Min security,Max money');

	for (var i = 0; i < children.length; i++) {
		var child = children[i];
		if (child.includes('home') || child == parent) { continue; }

		var info = '';
		info += child + ',';
		info += '' + ns.getServerRequiredHackingLevel(child) + ',';
		info += '' + ns.getServerNumPortsRequired(child) + ',';
		info += '' + ns.getServerMinSecurityLevel(child) + ',';
		info += '' + ns.getServerMaxMoney(child);
		ns.tprint(info);

		try {
			ns.nuke(child);
			await ns.scp('stats.js', child);
			ns.killall(child);
			var small = ns.getScriptRam('stats.js') > ns.getServerMaxRam(child);
			ns.exec('stats.js', small ? name : child, 1, child, name);
		} catch (error) {
			ns.tprint('Cannot recurse into: ', child);  // not enough ports
		}
		
	}
}