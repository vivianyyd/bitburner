/** 
 * @param {NS} ns 
 * Usage: `run stats.js home home`
 * This script recursively kills all processes on all servers. The `start` command must be used after running.
**/
export async function main(ns) {
	var name;
	var parent;
	if (ns.args.length == 0) {
		name = ns.getHostname();
		parent = ns.getHostname();
	}
	else {
		name = ns.args[0];
		parent = ns.args[1];
	}

	var children = ns.scan(name);
	for (let child of children) {
		if (child.includes('home') || child == parent) { continue; }
		var info = '';
		info += child + ',';
		info += '' + ns.getServerRequiredHackingLevel(child) + ',';
		info += '' + ns.getServerNumPortsRequired(child) + ',';
		info += '' + ns.getServerMinSecurityLevel(child) + ',';
		info += '' + ns.getServerMaxMoney(child);
		ns.tprint(info);
		ns.run('stats.js', 1, child, name);
	}
}