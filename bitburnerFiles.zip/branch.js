/** 
 * @param {NS} ns 
 * Breaks into child servers and initates setup process in them.
 * Initiates the weaken-grow-hack loop in the current server.
**/
export async function main(ns) {
	var name;
	var parent;
	if (ns.args.length == 0) {
		name = ns.getHostname();
		parent = ns.getHostname();
	}
	else {
		name = ns.args[0];
		parent = ns.args[1];
	}
	var children = ns.scan(name);
	for (let child of children) {
		if (child == parent) { continue; }
		ns.brutessh(child);
		ns.ftpcrack(child);
		ns.relaysmtp(child);
		ns.httpworm(child);
		ns.sqlinject(child);
		// automate backdoor if it ever takes less than 32G
		try {
			ns.nuke(child);
			await ns.scp(['branch.js', 'leaf.js', 'hackgw.js', 'weak.js'], child);
			ns.killall(child);
			var small = ns.getScriptRam('branch.js') > ns.getServerMaxRam(child);
			ns.exec('branch.js', small ? name : child, 1, child, name);
		} catch (error) {
			ns.tprint('Not enough ports to nuke: ', child);  // not enough ports
		}
	}
	ns.exec('leaf.js', name, 1);
}