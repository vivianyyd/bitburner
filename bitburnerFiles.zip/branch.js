/** 
 * @param {NS} ns 
 * Breaks into child servers and initates setup process in them.
 * Initiates the weaken-grow-hack loop in the current server.
**/
export async function main(ns) {
	var name;
	var parent;
	var xp = false;
	var args = []
	for (let arg of ns.args) {
		if (arg == '-x') { xp = true; }  // cheese hacking XP
		else { args.push(arg); }
	}
	if (args.length == 0) {
		name = ns.getHostname();
		parent = ns.getHostname();
	}
	else {
		name = args[0];
		parent = args[1];
	}
	var children = ns.scan(name);
	for (let child of children) {
		if (child == parent) { continue; }
		ns.brutessh(child);
		ns.ftpcrack(child);
		ns.relaysmtp(child);
		ns.httpworm(child);
		ns.sqlinject(child);
		try {
			ns.nuke(child);
			await ns.scp(['branch.js', 'leaf.js', 'hackgw.js', 'weak.js'], child);
			ns.killall(child);
			var small = ns.getScriptRam('branch.js') > ns.getServerMaxRam(child);
			if (xp) { ns.exec('branch.js', small ? name : child, 1, child, name, '-x'); }
			else { ns.exec('branch.js', small ? name : child, 1, child, name); }
		} catch (error) {
			ns.tprint('Not enough ports to nuke: ', child);
		}
	}
	if (xp) {
		var threads = Math.floor(ns.getServerMaxRam(name) / 1.75);
		if (threads > 0) { ns.spawn('weak.js', threads); }
	}
	else { ns.exec('leaf.js', name, 1); }
}