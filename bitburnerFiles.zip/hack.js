/** 
 * @param {NS} ns 
 * Should only be called by loop
**/
export async function main(ns) {
	var src = ns.args[0]
	var target = ns.args[1];
	var ram = ns.getServerMaxRam(src) - ns.getServerUsedRam(src) + ns.getScriptRam('hack.js');
	var advR = ns.getScriptRam('adv.js');

	var sets = Math.floor(ram / advR);
	ns.spawn('adv.js', sets, target);
}