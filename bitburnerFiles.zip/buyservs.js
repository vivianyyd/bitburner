/** @param {NS} ns **/
export async function main(ns) {
	// var ram = Math.pow(2, 13);  // I think 16 is overkill
	// var i = 0;
	// while (i < ns.getPurchasedServerLimit()) {
	// 	if (ns.getServerMoneyAvailable('home') > ns.getPurchasedServerCost(ram)) {
			
	// 		// leave these lines uncommented if there already exist all 25 servers
	// 		ns.killall('home-'+i);
	// 		ns.deleteServer('home-'+i);
			
	// 		var baby = ns.purchaseServer('home-'+i, ram);
	// 		await ns.scp(['loop.js', 'hack.js', 'adv.js'], baby);
	// 		ns.exec('loop.js', baby, 1, baby);
	// 		i++;
	// 	}
	// 	await ns.sleep(1000 * 60);
	// }
}