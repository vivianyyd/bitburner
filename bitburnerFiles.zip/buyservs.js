/** 
 * @param {NS} ns 
 * Ensures the user has at least [numservs] servers of RAM at least [ram], purchasing servers as necessary when possible. 
**/
export async function main(ns) {  // modify first two lines
	var ram = Math.pow(2, 20);  // 13, 18, 20
	var numservs = 6;

	var i = 0;
	while (i < numservs) {
		var name = 'home-' + i;
		let replacing = ns.serverExists(name);
		let baby = '';
		if (replacing) {
			if (ns.getServerMaxRam(name) >= ram) {  // do not delete
				i++;
			}
			else if (ns.getServerMoneyAvailable('home') > ns.getPurchasedServerCost(ram)) {
				ns.killall(name);
				ns.deleteServer(name);
				baby = ns.purchaseServer(baby, ram);
			}
		}
		else {
			if (ns.getServerMoneyAvailable('home') > ns.getPurchasedServerCost(ram)) {
				baby = ns.purchaseServer(name, ram);
			}
		}
		if (baby.length > 0) {  // successfully purchased
			await ns.scp(['branch.js', 'leaf.js', 'hackgw.js', 'weak.js'], baby);
			ns.exec('leaf.js', baby, 1, baby);
			i++;
		}
		await ns.sleep(1000 * 60);
	}
}